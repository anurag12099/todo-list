import { useState } from "react";
import { Pencil, Trash2, Calendar, Clock, CheckCircle, AlertCircle } from "lucide-react";
import { type Task } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { formatDate, isTaskDueSoon } from "@/lib/date-utils";
import { AddTaskDialog } from "./add-task-dialog";

interface TaskItemProps {
  task: Task;
}

export function TaskItem({ task }: TaskItemProps) {
  const { toast } = useToast();
  const [editDialogOpen, setEditDialogOpen] = useState(false);

  // Priority colors
  const priorityColors = {
    high: {
      border: "border-red-500",
      bg: "bg-red-500",
      text: "text-red-500",
      bgLight: "bg-red-100 dark:bg-red-950/30",
    },
    medium: {
      border: "border-amber-500",
      bg: "bg-amber-500",
      text: "text-amber-500",
      bgLight: "bg-amber-100 dark:bg-amber-950/30",
    },
    low: {
      border: "border-green-500",
      bg: "bg-green-500",
      text: "text-green-500",
      bgLight: "bg-green-100 dark:bg-green-950/30",
    },
  };

  const priorityColor = priorityColors[task.priority as keyof typeof priorityColors];

  // Handle task completion toggle
  const toggleCompletion = async () => {
    try {
      await apiRequest("PATCH", `/api/tasks/${task.id}`, {
        completed: !task.completed,
      });
      
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      
      if (!task.completed) {
        toast({
          title: "Task completed",
          description: `"${task.title}" has been marked as completed.`,
          variant: "success",
        });
      }
    } catch (error) {
      console.error("Error toggling task completion:", error);
      toast({
        title: "Error",
        description: "Failed to update task status.",
        variant: "destructive",
      });
    }
  };

  // Handle task deletion
  const deleteTask = async () => {
    try {
      await apiRequest("DELETE", `/api/tasks/${task.id}`);
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      toast({
        title: "Task deleted",
        description: "Task has been successfully deleted.",
        variant: "info",
      });
    } catch (error) {
      console.error("Error deleting task:", error);
      toast({
        title: "Error",
        description: "Failed to delete task.",
        variant: "destructive",
      });
    }
  };

  // Format first letter of priority to uppercase
  const formatPriority = (priority: string) => {
    return priority.charAt(0).toUpperCase() + priority.slice(1);
  };

  const dueSoon = isTaskDueSoon(task.dueDate, task.dueTime, task.completed);

  return (
    <>
      <div 
        className={cn(
          "bg-card rounded-lg shadow-sm p-4 transition-all duration-200 hover:shadow-md border border-border",
          `border-l-4 ${priorityColor.border}`,
          task.completed && "opacity-75"
        )}
      >
        <div className="flex items-start">
          {/* Checkbox */}
          <div className="pt-0.5">
            <button 
              onClick={toggleCompletion}
              className={cn(
                "w-5 h-5 rounded-full border flex items-center justify-center transition-colors duration-200",
                task.completed
                  ? "bg-primary border-primary text-primary-foreground"
                  : "border-input hover:border-primary"
              )}
            >
              {task.completed && <CheckCircle className="h-3 w-3" />}
            </button>
          </div>
          
          {/* Task Content */}
          <div className="ml-3 flex-1">
            <div className="flex items-start justify-between">
              <h3 
                className={cn(
                  "font-medium leading-5 text-foreground",
                  task.completed && "line-through opacity-50"
                )}
              >
                {task.title}
              </h3>
              <div className="flex space-x-1">
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={() => setEditDialogOpen(true)}
                  className="h-8 w-8 text-muted-foreground hover:text-foreground"
                >
                  <Pencil className="h-4 w-4" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={deleteTask}
                  className="h-8 w-8 text-muted-foreground hover:text-red-500"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            {task.description && (
              <p 
                className={cn(
                  "mt-1 text-sm text-muted-foreground",
                  task.completed && "line-through opacity-50"
                )}
              >
                {task.description}
              </p>
            )}
            
            <div className="mt-2 flex flex-wrap items-center text-xs text-muted-foreground gap-2">
              {/* Priority Badge */}
              <span 
                className={cn(
                  "inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium",
                  priorityColor.bgLight,
                  priorityColor.text
                )}
              >
                <span 
                  className={cn(
                    "w-1.5 h-1.5 rounded-full mr-1",
                    priorityColor.bg
                  )}
                ></span>
                {formatPriority(task.priority)}
                {task.priority === "high" && (
                  <AlertCircle className="ml-1 h-3 w-3" />
                )}
              </span>
              
              {/* Due Date */}
              {task.dueDate && (
                <span className="inline-flex items-center">
                  <Calendar className="mr-1 h-3 w-3" />
                  <span>{formatDate(task.dueDate)}</span>
                </span>
              )}
              
              {/* Due Time */}
              {task.dueTime && (
                <span className="inline-flex items-center">
                  <Clock className="mr-1 h-3 w-3" />
                  <span>{task.dueTime}</span>
                </span>
              )}
              
              {/* Due Soon Badge */}
              {dueSoon && !task.completed && (
                <span 
                  className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-red-100 dark:bg-red-950/30 text-red-800 dark:text-red-300"
                >
                  <AlertCircle className="mr-1 h-3 w-3" /> Due Soon
                </span>
              )}
            </div>
          </div>
        </div>
      </div>
      
      {/* Edit Task Dialog */}
      <AddTaskDialog 
        open={editDialogOpen} 
        onOpenChange={setEditDialogOpen} 
        editingTask={task} 
      />
    </>
  );
}
