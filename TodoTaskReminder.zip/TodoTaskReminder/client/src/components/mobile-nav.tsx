import { useState } from "react";
import { 
  ListTodo, 
  CalendarCheck2, 
  PlusCircle,
  Flag, 
  CheckSquare 
} from "lucide-react";
import { cn } from "@/lib/utils";
import { AddTaskDialog } from "./add-task-dialog";
import { ThemeToggle } from "./theme-toggle";

interface MobileNavProps {
  currentFilter: string;
  setFilter: (filter: string) => void;
}

export function MobileNav({ currentFilter, setFilter }: MobileNavProps) {
  const [addTaskOpen, setAddTaskOpen] = useState(false);
  
  return (
    <>
      <div className="md:hidden bg-background border-t border-border flex justify-around">
        <NavButton 
          icon={<ListTodo className="h-5 w-5" />} 
          label="All" 
          isActive={currentFilter === "all"}
          onClick={() => setFilter("all")}
        />
        <NavButton 
          icon={<CalendarCheck2 className="h-5 w-5" />} 
          label="Today" 
          isActive={currentFilter === "today"}
          onClick={() => setFilter("today")}
        />
        <div className="flex-1 flex items-center justify-center">
          <button 
            onClick={() => setAddTaskOpen(true)}
            className="bg-primary text-primary-foreground p-3 rounded-full flex items-center justify-center shadow-md -mt-8"
            aria-label="Add new task"
          >
            <PlusCircle className="h-6 w-6" />
          </button>
        </div>
        <NavButton 
          icon={<Flag className="h-5 w-5" />} 
          label="Priority" 
          isActive={["high", "medium", "low"].includes(currentFilter)}
          onClick={() => setFilter("high")}
          isPriority={true}
        />
        <NavButton 
          icon={<CheckSquare className="h-5 w-5" />} 
          label="Done" 
          isActive={currentFilter === "completed"}
          onClick={() => setFilter("completed")}
        />
      </div>
      
      <AddTaskDialog open={addTaskOpen} onOpenChange={setAddTaskOpen} />
    </>
  );
}

interface NavButtonProps {
  icon: React.ReactNode;
  label: string;
  isActive: boolean;
  onClick: () => void;
  isPriority?: boolean;
}

function NavButton({ icon, label, isActive, onClick, isPriority }: NavButtonProps) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "flex-1 py-3 flex flex-col items-center justify-center text-xs font-medium transition-colors",
        isActive 
          ? isPriority 
            ? "text-red-500 dark:text-red-400" 
            : "text-indigo-600 dark:text-indigo-400" 
          : "text-muted-foreground hover:text-foreground"
      )}
    >
      <div className="mb-1">{icon}</div>
      <span>{label}</span>
    </button>
  );
}
