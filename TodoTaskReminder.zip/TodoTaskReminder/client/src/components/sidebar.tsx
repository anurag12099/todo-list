import { cn } from "@/lib/utils";
import { 
  ListTodo, 
  CalendarCheck2, 
  Calendar, 
  CheckSquare, 
  Flag
} from "lucide-react";
import { AppIcon } from "./app-icon";
import { ThemeToggle } from "./theme-toggle";

interface SidebarProps {
  currentFilter: string;
  setFilter: (filter: string) => void;
}

export function Sidebar({ currentFilter, setFilter }: SidebarProps) {
  return (
    <div className="hidden md:flex md:w-64 bg-background border-r border-border flex-shrink-0 flex-col">
      <div className="p-4 border-b border-border flex items-center justify-between">
        <h1 className="text-xl font-bold text-primary flex items-center">
          <AppIcon className="mr-2 h-6 w-6" /> TaskRemind
        </h1>
        <ThemeToggle />
      </div>
      
      <div className="p-4">
        <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-3">
          Filters
        </h2>
        <ul className="space-y-2">
          <SidebarItem
            icon={<ListTodo className="mr-2 h-4 w-4" />}
            label="All Tasks"
            filter="all"
            currentFilter={currentFilter}
            onClick={() => setFilter("all")}
          />
          <SidebarItem
            icon={<CalendarCheck2 className="mr-2 h-4 w-4" />}
            label="Today"
            filter="today"
            currentFilter={currentFilter}
            onClick={() => setFilter("today")}
          />
          <SidebarItem
            icon={<Calendar className="mr-2 h-4 w-4" />}
            label="Upcoming"
            filter="upcoming"
            currentFilter={currentFilter}
            onClick={() => setFilter("upcoming")}
          />
          <SidebarItem
            icon={<CheckSquare className="mr-2 h-4 w-4" />}
            label="Completed"
            filter="completed"
            currentFilter={currentFilter}
            onClick={() => setFilter("completed")}
          />
        </ul>
      </div>
      
      <div className="p-4 border-t border-border">
        <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-3">
          Priority
        </h2>
        <ul className="space-y-2">
          <SidebarItem
            icon={<span className="w-3 h-3 rounded-full bg-red-500 mr-2" />}
            label="High Priority"
            filter="high"
            currentFilter={currentFilter}
            onClick={() => setFilter("high")}
            color="text-red-500 bg-red-50"
          />
          <SidebarItem
            icon={<span className="w-3 h-3 rounded-full bg-amber-500 mr-2" />}
            label="Medium Priority"
            filter="medium"
            currentFilter={currentFilter}
            onClick={() => setFilter("medium")}
            color="text-amber-500 bg-amber-50"
          />
          <SidebarItem
            icon={<span className="w-3 h-3 rounded-full bg-green-500 mr-2" />}
            label="Low Priority"
            filter="low"
            currentFilter={currentFilter}
            onClick={() => setFilter("low")}
            color="text-green-500 bg-green-50"
          />
        </ul>
      </div>
    </div>
  );
}

// Sidebar item component
function SidebarItem({ 
  icon, 
  label, 
  filter, 
  currentFilter, 
  onClick,
  color
}: { 
  icon: React.ReactNode; 
  label: string; 
  filter: string; 
  currentFilter: string; 
  onClick: () => void;
  color?: string;
}) {
  const isActive = currentFilter === filter;
  const isPriority = ['high', 'medium', 'low'].includes(filter);
  
  return (
    <li>
      <button 
        onClick={onClick} 
        className={cn(
          "w-full text-left px-3 py-2 rounded-md transition-colors duration-150 flex items-center",
          isActive 
            ? isPriority 
              ? color 
              : "bg-indigo-600 text-white" 
            : "hover:bg-accent"
        )}
      >
        {icon}
        {label}
      </button>
    </li>
  );
}
