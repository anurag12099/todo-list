import * as React from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter,
  DialogClose
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { CalendarIcon, CheckIcon, FlagIcon } from "lucide-react";
import { insertTaskSchema, type InsertTask, type Task } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { getISODateString } from "@/lib/date-utils";

interface AddTaskDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editingTask?: Task;
}

export function AddTaskDialog({ open, onOpenChange, editingTask }: AddTaskDialogProps) {
  const { toast } = useToast();
  const isEditing = !!editingTask;

  // Set up form with validation
  const form = useForm<InsertTask>({
    resolver: zodResolver(insertTaskSchema),
    defaultValues: {
      title: editingTask?.title || "",
      description: editingTask?.description || "",
      priority: editingTask?.priority || "medium",
      dueDate: editingTask?.dueDate || "",
      dueTime: editingTask?.dueTime || "",
      completed: editingTask?.completed || false,
      notify: editingTask?.notify || false,
    },
  });

  // Update form values when editing task changes
  React.useEffect(() => {
    if (editingTask) {
      form.reset({
        title: editingTask.title,
        description: editingTask.description || "",
        priority: editingTask.priority,
        dueDate: editingTask.dueDate || "",
        dueTime: editingTask.dueTime || "",
        completed: editingTask.completed,
        notify: editingTask.notify,
      });
    }
  }, [editingTask, form]);

  // Handle form submission
  const onSubmit = async (data: InsertTask) => {
    try {
      if (isEditing && editingTask.id) {
        // Update existing task
        await apiRequest("PATCH", `/api/tasks/${editingTask.id}`, data);
        toast({
          title: "Task updated",
          description: "Your task has been updated successfully.",
          variant: "success",
        });
      } else {
        // Create new task
        await apiRequest("POST", "/api/tasks", data);
        toast({
          title: "Task created",
          description: "Your new task has been added.",
          variant: "success",
        });
      }
      
      // Reset form and close dialog
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      form.reset();
      onOpenChange(false);
    } catch (error) {
      console.error("Error saving task:", error);
      toast({
        title: "Error",
        description: "Failed to save task. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Watch priority to conditionally show notification checkbox
  const priority = form.watch("priority");

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Edit Task" : "Add New Task"}</DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            {/* Task Title */}
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Task Title *</FormLabel>
                  <FormControl>
                    <Input placeholder="What needs to be done?" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Description */}
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Add details about this task (optional)"
                      className="resize-none"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Priority */}
            <FormField
              control={form.control}
              name="priority"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Priority Level *</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="flex space-x-2"
                    >
                      <FormItem className="flex-1 flex items-center space-x-0">
                        <FormControl>
                          <RadioGroupItem value="high" className="sr-only" id="high" />
                        </FormControl>
                        <FormLabel
                          htmlFor="high"
                          className={`w-full flex items-center justify-center py-2 px-3 border rounded-md cursor-pointer text-center ${
                            field.value === "high"
                              ? "bg-red-100 border-red-500 text-red-500"
                              : "hover:bg-gray-50"
                          }`}
                        >
                          <FlagIcon className="h-4 w-4 mr-1" /> High
                        </FormLabel>
                      </FormItem>
                      
                      <FormItem className="flex-1 flex items-center space-x-0">
                        <FormControl>
                          <RadioGroupItem value="medium" className="sr-only" id="medium" />
                        </FormControl>
                        <FormLabel
                          htmlFor="medium"
                          className={`w-full flex items-center justify-center py-2 px-3 border rounded-md cursor-pointer text-center ${
                            field.value === "medium"
                              ? "bg-amber-100 border-amber-500 text-amber-500"
                              : "hover:bg-gray-50"
                          }`}
                        >
                          <FlagIcon className="h-4 w-4 mr-1" /> Medium
                        </FormLabel>
                      </FormItem>
                      
                      <FormItem className="flex-1 flex items-center space-x-0">
                        <FormControl>
                          <RadioGroupItem value="low" className="sr-only" id="low" />
                        </FormControl>
                        <FormLabel
                          htmlFor="low"
                          className={`w-full flex items-center justify-center py-2 px-3 border rounded-md cursor-pointer text-center ${
                            field.value === "low"
                              ? "bg-green-100 border-green-500 text-green-500"
                              : "hover:bg-gray-50"
                          }`}
                        >
                          <FlagIcon className="h-4 w-4 mr-1" /> Low
                        </FormLabel>
                      </FormItem>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Due Date */}
            <FormField
              control={form.control}
              name="dueDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Due Date</FormLabel>
                  <FormControl>
                    <div className="flex items-center">
                      <CalendarIcon className="mr-2 h-4 w-4 opacity-70" />
                      <Input
                        type="date"
                        placeholder="Select a date"
                        {...field}
                        value={field.value || ""}
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Due Time */}
            <FormField
              control={form.control}
              name="dueTime"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Due Time</FormLabel>
                  <FormControl>
                    <Input
                      type="time"
                      placeholder="Select a time"
                      {...field}
                      value={field.value || ""}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Notification (only show for high priority tasks) */}
            {priority === "high" && (
              <FormField
                control={form.control}
                name="notify"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Send notification reminders</FormLabel>
                      <p className="text-sm text-muted-foreground">
                        High priority tasks will send notifications as the deadline approaches
                      </p>
                    </div>
                  </FormItem>
                )}
              />
            )}
            
            <DialogFooter className="flex gap-2 pt-4">
              <DialogClose asChild>
                <Button type="button" variant="outline">Cancel</Button>
              </DialogClose>
              <Button type="submit">
                {isEditing ? "Update Task" : "Add Task"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
