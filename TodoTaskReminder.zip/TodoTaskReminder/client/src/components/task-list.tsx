import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Task } from "@shared/schema";
import { TaskItem } from "./task-item";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, Plus } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { AddTaskDialog } from "./add-task-dialog";

interface TaskListProps {
  filter: string;
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

export function TaskList({ filter, searchQuery, onSearchChange }: TaskListProps) {
  const [addTaskDialogOpen, setAddTaskDialogOpen] = useState(false);
  
  // Fetch tasks from API
  const { data: tasks, isLoading, error } = useQuery<Task[]>({
    queryKey: ['/api/tasks'],
  });
  
  // Apply filters and search
  const filteredTasks = tasks ? filterTasks(tasks, filter, searchQuery) : [];
  
  // Get empty state message based on the current filter
  const getEmptyStateMessage = () => {
    if (searchQuery) return "No tasks match your search criteria";
    
    switch (filter) {
      case "all":
        return "You have no tasks. Add a new task to get started.";
      case "today":
        return "No tasks scheduled for today";
      case "upcoming":
        return "No upcoming tasks";
      case "completed":
        return "You haven't completed any tasks yet";
      case "high":
        return "No high priority tasks";
      case "medium":
        return "No medium priority tasks";
      case "low":
        return "No low priority tasks";
      default:
        return "No tasks found";
    }
  };
  
  // Render loading state
  if (isLoading) {
    return (
      <div className="max-w-3xl mx-auto space-y-4">
        <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
          <div className="relative">
            <SearchInput value={searchQuery} onChange={onSearchChange} />
          </div>
        </div>
        {[1, 2, 3].map((i) => (
          <div key={i} className="bg-white rounded-lg shadow-sm p-4">
            <div className="flex">
              <Skeleton className="h-5 w-5 rounded-full" />
              <div className="ml-3 flex-1">
                <Skeleton className="h-6 w-3/4 mb-2" />
                <Skeleton className="h-4 w-1/2 mb-2" />
                <div className="flex gap-2">
                  <Skeleton className="h-5 w-16 rounded-full" />
                  <Skeleton className="h-5 w-16 rounded-full" />
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }
  
  // Render error state
  if (error) {
    return (
      <div className="max-w-3xl mx-auto">
        <div className="bg-red-50 border-l-4 border-red-500 p-4 rounded-lg">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-red-500" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-9v4a1 1 0 01-2 0v-4a1 1 0 112 0zm0-4a1 1 0 11-2 0 1 1 0 012 0z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-red-800">Error loading tasks</h3>
              <div className="mt-2 text-sm text-red-700">
                <p>There was an error loading your tasks. Please try again later.</p>
              </div>
              <div className="mt-4">
                <Button 
                  size="sm" 
                  onClick={() => window.location.reload()}
                >Retry</Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="max-w-3xl mx-auto space-y-4">
      {/* Search and Add Section */}
      <div className="bg-card rounded-lg shadow-sm p-4 mb-4 border border-border">
        <div className="relative">
          <SearchInput value={searchQuery} onChange={onSearchChange} />
        </div>
      </div>
      
      {/* Empty State */}
      {filteredTasks.length === 0 && (
        <div className="bg-card rounded-lg shadow-sm p-8 text-center border border-border">
          <div className="text-muted-foreground mb-3">
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              className="mx-auto h-12 w-12" 
              fill="none" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
            >
              <path 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                strokeWidth={2} 
                d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" 
              />
            </svg>
          </div>
          <h3 className="text-lg font-medium mb-1">No tasks found</h3>
          <p className="text-muted-foreground mb-4">{getEmptyStateMessage()}</p>
          <Button 
            onClick={() => setAddTaskDialogOpen(true)}
            className="bg-primary hover:bg-primary/90"
          >
            <Plus className="mr-1 h-4 w-4" /> Add New Task
          </Button>
        </div>
      )}
      
      {/* Task List */}
      {filteredTasks.map((task) => (
        <TaskItem key={task.id} task={task} />
      ))}
      
      {/* Add Task Dialog */}
      <AddTaskDialog 
        open={addTaskDialogOpen} 
        onOpenChange={setAddTaskDialogOpen} 
      />
    </div>
  );
}

// Helper function to filter tasks
function filterTasks(tasks: Task[], filter: string, searchQuery: string): Task[] {
  // First apply text search
  let filtered = tasks;
  
  if (searchQuery) {
    const query = searchQuery.toLowerCase();
    filtered = filtered.filter(task => 
      task.title.toLowerCase().includes(query) || 
      (task.description && task.description.toLowerCase().includes(query))
    );
  }
  
  // Then apply status filter
  switch (filter) {
    case "all":
      // No additional filtering needed
      break;
    case "today":
      const today = new Date().toISOString().split('T')[0];
      filtered = filtered.filter(task => task.dueDate === today);
      break;
    case "upcoming":
      const now = new Date();
      const todayStr = now.toISOString().split('T')[0];
      filtered = filtered.filter(task => task.dueDate && task.dueDate > todayStr && !task.completed);
      break;
    case "completed":
      filtered = filtered.filter(task => task.completed);
      break;
    case "high":
      filtered = filtered.filter(task => task.priority === "high");
      break;
    case "medium":
      filtered = filtered.filter(task => task.priority === "medium");
      break;
    case "low":
      filtered = filtered.filter(task => task.priority === "low");
      break;
  }
  
  // Sort tasks: incomplete first, then by priority, then by due date
  return filtered.sort((a, b) => {
    // Incomplete tasks first
    if (a.completed !== b.completed) return a.completed ? 1 : -1;
    
    // Then by priority (high -> medium -> low)
    const priorityValue = { high: 3, medium: 2, low: 1 };
    const aPriority = priorityValue[a.priority as keyof typeof priorityValue] || 0;
    const bPriority = priorityValue[b.priority as keyof typeof priorityValue] || 0;
    
    if (aPriority !== bPriority) return bPriority - aPriority;
    
    // Then by due date (if present)
    if (a.dueDate && b.dueDate) {
      const aDateTime = new Date(`${a.dueDate}T${a.dueTime || '23:59:59'}`).getTime();
      const bDateTime = new Date(`${b.dueDate}T${b.dueTime || '23:59:59'}`).getTime();
      return aDateTime - bDateTime;
    }
    
    return 0;
  });
}

// Search input component
function SearchInput({ value, onChange }: { value: string, onChange: (value: string) => void }) {
  return (
    <>
      <Input
        type="text"
        placeholder="Search tasks..."
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="pl-10 pr-4 py-2"
      />
      <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground">
        <Search className="h-4 w-4" />
      </div>
    </>
  );
}
