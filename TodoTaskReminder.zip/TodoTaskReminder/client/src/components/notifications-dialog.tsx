import { useState, useEffect } from "react";
import { 
  AlertCircle, 
  BellRing, 
  Clock, 
  Calendar,
  X,
  CheckCircle
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Task } from "@shared/schema";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { formatDate, getTimeRemaining } from "@/lib/date-utils";
import { getHighPriorityNotifications } from "@/lib/notifications";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { cn } from "@/lib/utils";

export function NotificationsDialog() {
  const { data: tasks } = useQuery<Task[]>({
    queryKey: ['/api/tasks'],
  });
  
  const [open, setOpen] = useState(false);
  
  // Calculate high priority notifications
  const notifications = tasks ? getHighPriorityNotifications(tasks) : [];
  const hasNotifications = notifications.length > 0;
  
  // Mark task as complete
  const completeTask = async (taskId: number) => {
    try {
      await apiRequest("PATCH", `/api/tasks/${taskId}`, { completed: true });
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
    } catch (error) {
      console.error("Error completing task:", error);
    }
  };
  
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <BellRing className="h-5 w-5" />
          {hasNotifications && (
            <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full animate-pulse" />
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0" align="end">
        <div className="px-4 py-3 border-b border-gray-200 bg-gray-50">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-medium">Notifications</h3>
            <span className="bg-red-100 text-red-800 text-xs font-medium px-2.5 py-0.5 rounded">
              {notifications.length} high priority
            </span>
          </div>
        </div>
        
        <div className="max-h-[300px] overflow-y-auto">
          {notifications.length === 0 ? (
            <div className="p-4 text-center text-gray-500">
              <BellRing className="h-8 w-8 mx-auto mb-2 text-gray-400" />
              <p className="text-sm">No notifications at this time</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-200">
              {notifications.map((task) => (
                <div key={task.id} className="p-4 hover:bg-gray-50">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start">
                      <AlertCircle className="h-5 w-5 text-red-500 mt-0.5 mr-2 flex-shrink-0" />
                      <div>
                        <h4 className="text-sm font-medium text-gray-900">{task.title}</h4>
                        <div className="mt-1 flex items-center text-xs text-gray-500">
                          <div className="flex items-center mr-2">
                            <Clock className="h-3 w-3 mr-1" />
                            <span>Due in {getTimeRemaining(task.dueDate, task.dueTime)}</span>
                          </div>
                          {task.dueDate && (
                            <div className="flex items-center">
                              <Calendar className="h-3 w-3 mr-1" />
                              <span>{formatDate(task.dueDate)}</span>
                              {task.dueTime && <span className="ml-1">{task.dueTime}</span>}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-6 w-6 rounded-full text-gray-400 hover:text-green-600"
                      onClick={() => completeTask(task.id)}
                    >
                      <CheckCircle className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}
