import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Initialize theme from localStorage or system preference
const initializeTheme = () => {
  const theme = localStorage.getItem('theme') || 'system';
  const rootElement = window.document.documentElement;
  
  rootElement.classList.remove('light', 'dark');
  
  if (theme === 'system') {
    const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches
      ? 'dark'
      : 'light';
    rootElement.classList.add(systemTheme);
  } else {
    rootElement.classList.add(theme);
  }
};

// Initialize theme on page load
initializeTheme();

createRoot(document.getElementById("root")!).render(<App />);
