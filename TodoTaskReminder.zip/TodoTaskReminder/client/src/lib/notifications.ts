import { type Task } from "@shared/schema";
import { isTaskDueSoon } from "./date-utils";

// Function to check for high priority tasks that are due soon
export function getHighPriorityNotifications(tasks: Task[]): Task[] {
  return tasks.filter(task => 
    task.priority === 'high' && 
    !task.completed && 
    task.notify && 
    isTaskDueSoon(task.dueDate, task.dueTime)
  );
}

// Check if there are any high priority tasks due soon
export function hasHighPriorityTasksDueSoon(tasks: Task[]): boolean {
  return getHighPriorityNotifications(tasks).length > 0;
}

// Get notification count
export function getNotificationCount(tasks: Task[]): number {
  return getHighPriorityNotifications(tasks).length;
}
