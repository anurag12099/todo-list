// Format date for display
export function formatDate(dateString?: string | null): string {
  if (!dateString) return '';
  
  const date = new Date(dateString);
  const today = new Date();
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);
  
  // Check if same day
  const isSameDay = (date1: Date, date2: Date) => {
    return (
      date1.getFullYear() === date2.getFullYear() &&
      date1.getMonth() === date2.getMonth() &&
      date1.getDate() === date2.getDate()
    );
  };
  
  if (isSameDay(date, today)) return 'Today';
  if (isSameDay(date, tomorrow)) return 'Tomorrow';
  
  // Format as "MMM D" (e.g., "Jan 5")
  return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

// Check if a task is due soon (within 24 hours)
export function isTaskDueSoon(dueDate?: string | null, dueTime?: string | null, completed: boolean = false): boolean {
  if (!dueDate || completed) return false;
  
  const now = new Date();
  const dueDateTime = new Date(`${dueDate}T${dueTime || '23:59:59'}`);
  
  // Calculate difference in hours
  const diffHours = (dueDateTime.getTime() - now.getTime()) / (1000 * 60 * 60);
  
  // Task is due soon if it's within the next 24 hours
  return diffHours > 0 && diffHours < 24;
}

// Get formatted date string in YYYY-MM-DD format for date inputs
export function getISODateString(date: Date = new Date()): string {
  return date.toISOString().split('T')[0];
}

// Get time remaining string for a task
export function getTimeRemaining(dueDate?: string | null, dueTime?: string | null): string {
  if (!dueDate) return '';
  
  const now = new Date();
  const dueDateTime = new Date(`${dueDate}T${dueTime || '23:59:59'}`);
  
  // Calculate difference in hours
  const diffHours = (dueDateTime.getTime() - now.getTime()) / (1000 * 60 * 60);
  
  if (diffHours < 0) return 'Overdue';
  if (diffHours < 1) return `${Math.round(diffHours * 60)} minutes`;
  if (diffHours < 24) return `${Math.round(diffHours)} hours`;
  
  const days = Math.floor(diffHours / 24);
  return `${days} ${days === 1 ? 'day' : 'days'}`;
}
