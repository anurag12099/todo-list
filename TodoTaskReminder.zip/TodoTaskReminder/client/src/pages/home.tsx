import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Task } from "@shared/schema";
import { Sidebar } from "@/components/sidebar";
import { TaskList } from "@/components/task-list";
import { NotificationsDialog } from "@/components/notifications-dialog";
import { MobileNav } from "@/components/mobile-nav";
import { AddTaskDialog } from "@/components/add-task-dialog";
import { useToast } from "@/hooks/use-toast";
import { Plus } from "lucide-react";
import { AppIcon } from "@/components/app-icon";
import { ThemeToggle } from "@/components/theme-toggle";
import { Button } from "@/components/ui/button";
import { getHighPriorityNotifications } from "@/lib/notifications";
import { getTimeRemaining } from "@/lib/date-utils";

export default function Home() {
  const { toast } = useToast();
  
  // State for currently selected filter
  const [currentFilter, setCurrentFilter] = useState("all");
  
  // State for task search query
  const [searchQuery, setSearchQuery] = useState("");
  
  // State for add task dialog
  const [addTaskOpen, setAddTaskOpen] = useState(false);
  
  // Fetch tasks
  const { data: tasks, isLoading } = useQuery<Task[]>({
    queryKey: ['/api/tasks'],
  });
  
  // Set up notifications for high priority tasks
  useEffect(() => {
    if (!tasks) return;
    
    const checkNotifications = () => {
      const highPriorityTasks = getHighPriorityNotifications(tasks);
      
      highPriorityTasks.forEach(task => {
        // Show notification for high priority tasks due soon
        if (Math.random() < 0.1) { // Random check to avoid too many notifications at once
          toast({
            title: "High Priority Task Reminder",
            description: `"${task.title}" is due in ${getTimeRemaining(task.dueDate, task.dueTime)}`,
            variant: "priority",
          });
        }
      });
    };
    
    // Check for notifications on load
    checkNotifications();
    
    // Set up interval to check for notifications periodically
    const interval = setInterval(checkNotifications, 60000); // Check every minute
    
    return () => clearInterval(interval);
  }, [tasks, toast]);
  
  // Get title for current filter
  const getFilterTitle = () => {
    switch (currentFilter) {
      case "all": return "All Tasks";
      case "today": return "Today's Tasks";
      case "upcoming": return "Upcoming Tasks";
      case "completed": return "Completed Tasks";
      case "high": return "High Priority";
      case "medium": return "Medium Priority";
      case "low": return "Low Priority";
      default: return "Tasks";
    }
  };
  
  return (
    <div className="flex flex-col md:flex-row h-screen bg-background">
      {/* Sidebar for larger screens */}
      <Sidebar currentFilter={currentFilter} setFilter={setCurrentFilter} />
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Top Navigation */}
        <div className="bg-background border-b border-border shadow-sm z-10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between h-16 items-center">
              <div className="md:hidden flex items-center">
                <h1 className="text-xl font-bold text-primary flex items-center">
                  <AppIcon className="mr-2 h-6 w-6" /> TaskRemind
                </h1>
              </div>
              <div className="hidden md:flex md:items-center">
                <span className="text-xl font-semibold">{getFilterTitle()}</span>
              </div>
              <div className="flex items-center">
                {/* Notification Bell */}
                <div className="relative mr-4">
                  <NotificationsDialog />
                </div>
                {/* Theme Toggle */}
                <ThemeToggle className="mr-2" />
                {/* Add Button */}
                <Button 
                  onClick={() => setAddTaskOpen(true)}
                  className="bg-primary hover:bg-primary/90"
                >
                  <Plus className="mr-1 h-4 w-4" /> Add Task
                </Button>
              </div>
            </div>
          </div>
        </div>
        
        {/* Task List */}
        <div className="flex-1 overflow-y-auto p-4 bg-background">
          <TaskList 
            filter={currentFilter} 
            searchQuery={searchQuery} 
            onSearchChange={setSearchQuery} 
          />
        </div>
        
        {/* Mobile navigation */}
        <MobileNav currentFilter={currentFilter} setFilter={setCurrentFilter} />
      </div>
      
      {/* Add Task Dialog */}
      <AddTaskDialog open={addTaskOpen} onOpenChange={setAddTaskOpen} />
    </div>
  );
}
