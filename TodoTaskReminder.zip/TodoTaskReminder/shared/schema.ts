import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Define priority enum
export const PriorityLevel = {
  HIGH: "high",
  MEDIUM: "medium",
  LOW: "low",
} as const;

export type PriorityLevelType = (typeof PriorityLevel)[keyof typeof PriorityLevel];

// Task table schema
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  priority: text("priority").notNull().$type<PriorityLevelType>(),
  dueDate: text("due_date"), // Store as ISO string
  dueTime: text("due_time"),
  completed: boolean("completed").notNull().default(false),
  notify: boolean("notify").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Schema for inserting a task
export const insertTaskSchema = createInsertSchema(tasks)
  .omit({ id: true, createdAt: true })
  .extend({
    title: z.string().min(1, "Title is required"),
    priority: z.enum(["high", "medium", "low"]),
    dueDate: z.string().optional().nullable(),
    dueTime: z.string().optional().nullable(),
  });

// Schema for updating a task
export const updateTaskSchema = insertTaskSchema.extend({
  id: z.number(),
});

// Types
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type UpdateTask = z.infer<typeof updateTaskSchema>;
export type Task = typeof tasks.$inferSelect;

// Original user schema (keeping for compatibility)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
