import { tasks, type Task, type InsertTask, type UpdateTask, users, type User, type InsertUser } from "@shared/schema";

// Storage interface with CRUD operations
export interface IStorage {
  // Task operations
  getTasks(): Promise<Task[]>;
  getTask(id: number): Promise<Task | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, task: Partial<InsertTask>): Promise<Task | undefined>;
  deleteTask(id: number): Promise<boolean>;
  
  // User operations (keeping for compatibility)
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private tasks: Map<number, Task>;
  private users: Map<number, User>;
  private taskCurrentId: number;
  private userCurrentId: number;

  constructor() {
    this.tasks = new Map();
    this.users = new Map();
    this.taskCurrentId = 1;
    this.userCurrentId = 1;
  }

  // Task operations
  async getTasks(): Promise<Task[]> {
    return Array.from(this.tasks.values()).sort((a, b) => {
      // Sort by completion status first
      if (a.completed !== b.completed) return a.completed ? 1 : -1;
      
      // Then by priority (high -> medium -> low)
      const priorityValue = { high: 3, medium: 2, low: 1 };
      const aPriority = priorityValue[a.priority as keyof typeof priorityValue] || 0;
      const bPriority = priorityValue[b.priority as keyof typeof priorityValue] || 0;
      
      if (aPriority !== bPriority) return bPriority - aPriority;
      
      // Then by due date (if present)
      if (a.dueDate && b.dueDate) {
        return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
      }
      
      return 0;
    });
  }

  async getTask(id: number): Promise<Task | undefined> {
    return this.tasks.get(id);
  }

  async createTask(insertTask: InsertTask): Promise<Task> {
    const id = this.taskCurrentId++;
    const now = new Date();
    const task: Task = { 
      ...insertTask, 
      id, 
      createdAt: now 
    };
    this.tasks.set(id, task);
    return task;
  }

  async updateTask(id: number, updateData: Partial<InsertTask>): Promise<Task | undefined> {
    const task = await this.getTask(id);
    if (!task) return undefined;

    const updatedTask: Task = { ...task, ...updateData };
    this.tasks.set(id, updatedTask);
    return updatedTask;
  }

  async deleteTask(id: number): Promise<boolean> {
    return this.tasks.delete(id);
  }

  // User operations (keeping for compatibility)
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
}

// Create and export storage instance
export const storage = new MemStorage();
